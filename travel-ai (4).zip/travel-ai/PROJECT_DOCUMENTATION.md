# AI Travel Planner - Loyiha Haqida Ma'lumot (Project Overview)

Ushbu hujjat sun'iy intellekt (AI) modellariga loyihaning qanday ishlashi, qanday funksiyalarga ega ekanligi va uning tuzilishini tushuntirish uchun maxsus yozilgan mukammal qo'llanmadir.

## 1. Loyiha Qisqacha Mazmuni (Summary)
**AI Travel Planner** — bu sayohat qilishni xohlovchilar uchun mo'ljallangan sun'iy intellektga asoslangan aqlli sayohat platformasi. Ushbu sayt orqali foydalanuvchilar o'zlari uchun turli xil sayohat paketlarini izlashi, AI yordamida sayohat bo'yicha maslahatlar olishi, turlarni bron qilishi va adminlar butun jarayonni boshqarishi mumkin.

## 2. Texnologiyalar Steki (Tech Stack)
* **Backend:** Python, FastAPI (Web Framework), Uvicorn (Server)
* **Ma'lumotlar Bazasi:** SQLite (`travel.db`)
* **Frontend:** Vanilla HTML, CSS, JavaScript (Frontend to'g'ridan-to'g'ri FastAPI orqali statik tarzda ishga tushadi)
* **Sun'iy Intellekt (AI):** 
  - *Google Gemini (gemini-flash-latest):* Asosiy AI model sifatida ishlatiladi.
  - *OpenAI (gpt-4o-mini):* Gemini ishlamay qolganda yoki xatolik berganda zaxira (fallback) variant sifatida ishlatiladi.

## 3. Loyihadagi Asosiy Funksiyalar (Core Features)

### A. Foydalanuvchi Autentifikatsiyasi (Auth)
* **Ro'yxatdan o'tish va Kirish:** Foydalanuvchilar Ismi, Telefon raqami va Parol orqali ro'yxatdan o'tadi. Sessiya xavfsizligi Cookie asosida (session_token) ishlaydi.
* **Tizimdan chiqish (Logout):** Sessiyani yakunlash.

### B. Sayohat Turlari va Joylar (Destinations)
* **Turlarni ko'rish va qidirish:** Mavjud turlarni (masalan, Registon, Dubay, Maldiv) nomi yoki joylashuvi bo'yicha qidirish va turlarga ko'ra filtrlash imkoniyati.
* **Saqlash va Yoqtirish (Save & Like):** Foydalanuvchilar o'zlariga yoqqan sayohat yo'nalishlariga Like bosishlari yoki o'z profiliga saqlab qo'yishlari mumkin.
* **Bron qilish (Booking):** Foydalanuvchilar turlarni tanlab, sayohatga buyurtma (bron) berishlari mumkin.
* **Fikrlar va Reyting (Comments & Ratings):** Sayohatlar tagiga foydalanuvchilar o'z sharhlarini yozib, 1 dan 5 yulduzgacha baho bera oladilar. Baholar o'rtachasi avtomatik hisoblanib ko'rinadi.

### C. Sun'iy Intellekt Imkoniyatlari (AI Features)
* **AI Chat (Sayohat Maslahatchisi):** Saytning o'ng tomonida yoki alohida darchada ishlaydigan AI yordamchisi. U ma'lumotlar bazasidagi barcha mavjud turlar haqida biladi va foydalanuvchiga uning xohishiga qarab (arzon narx, tog', dengiz) eng mos keladigan turlarni O'zbek tilida tavsiya qiladi.
* **AI Imagine (Joyni tasavvur qilish):** Foydalanuvchi o'zi xohlagan xayolidagi joyni matn ko'rinishida yozganda, AI uni tahlil qilib, shu joy haqida JSON formatida ma'lumot qaytaradi (narxi, qisqacha tavsifi, lokatsiyasi). Va bu ma'lumot saytda chiroyli vizual kartochka shaklida namoyon bo'ladi.

### D. Admin Panel (Boshqaruv qismi)
Faqat admin huquqi bor foydalanuvchilar kira oladigan yopiq qism.
* **Statistika:** Jami ro'yxatdan o'tgan foydalanuvchilar soni, qilingan jami bronlar, platforma keltirgan jami daromad va eng ko'p bron qilingan "Top-5" davlatlar reytingini ko'rsatib turadi.
* **Buyurtmalar (Bookings) va Foydalanuvchilarni ko'rish:** Barcha qilingan xaridlar (bronlar) va tizim a'zolari ro'yxatini ko'rish imkoniyati.

---

## 4. Ma'lumotlar Bazasi Tuzilishi (Database Schema)

Loyiha SQLite ma'lumotlar bazasidan foydalanadi va unda jami 6 ta jadval (table) mavjud:

1. **users:** Foydalanuvchi ma'lumotlari (`id`, `name`, `phone`, `password`, `is_admin`, `session_token`, `created_at`).
2. **destinations:** Sayohat paketlari/joylar haqida ma'lumot (`id`, `title`, `description`, `location`, `price`, `days`, `type`, `image_url`, `extra_images`, `includes`, `likes`, `bookings`, `lat`, `lon`).
3. **comments:** Joylarga bildirilgan fikrlar (`id`, `destination_id`, `user_id`, `text`, `rating`, `timestamp`).
4. **saved_cities:** Foydalanuvchi tomondan saqlab qo'yilgan joylar pichkasi.
5. **bookings:** Bron qilingan sayohatlar jadvali (`id`, `user_id`, `destination_id`, `guests`, `timestamp`).
6. **chat_history:** Foydalanuvchi va AI o'rtasidagi suhbatlar tarixi.

---

## 5. API Yo'nalishlari (API Endpoints)
Quyida backend orqali ishlangan asosiy API yo'llari:
* `POST /api/auth/register` - Yangi foydalanuvchi yaratish
* `POST /api/auth/login` - Tizimga kirish
* `GET /api/destinations` - Barcha turlarni va ularning reytingini olish
* `POST /api/destinations/book` - Joyni bron qilish
* `POST /api/destinations/comment` - Fikr yozib qoldirish
* `POST /api/ai/chat` - AI maslahatchiga savol yuborish
* `POST /api/ai/imagine` - Xayoldagi joy tasvirini AI orqali generatsiya qilish
* `GET /api/admin/stats` - Admin uchun umumiy statistika

---

## Boshqa AI larga Ko'rsatma (Instruction for other AIs):
Agar sizga ushbu proektni o'zgartirish, qandaydir funksiya qoshish yoki debug qilish topshirilsa:
1. Backend kodi `backend/main.py` da, barcha SQL mantiqlari ham shu yerda joylashgan.
2. Frontend `frontend/` papkasi ichida joylashgan va FastAPI ning `StaticFiles` orqali ulangan (`/` root endpoint ga).
3. Yangi paket qo'shish kerak bo'lsa `.env` da klitlar (GEMINI_API_KEY, OPENAI_API_KEY) borligini yodda tuting. 
4. Ma'lumotlar bazasini qo'lda o'zgartirmang, barchasi `main.py` ishga tushganda `init_db()` orqali avtomatik yaratiladi va kerak bo'lsa ma'lumotlar bilan to'ldiriladi.
