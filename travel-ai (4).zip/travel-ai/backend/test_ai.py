import os
from dotenv import load_dotenv

load_dotenv()

try:
    from google import genai
    HAS_GEMINI = True
except ImportError as e:
    HAS_GEMINI = False
    print("Gemini import error:", e)

try:
    from openai import OpenAI as OpenAIClient
    HAS_OPENAI = True
except ImportError as e:
    HAS_OPENAI = False
    print("OpenAI import error:", e)

print("HAS_GEMINI:", HAS_GEMINI)
print("HAS_OPENAI:", HAS_OPENAI)

if HAS_OPENAI:
    try:
        api_key = os.getenv("OPENAI_API_KEY")
        client = OpenAIClient(api_key=api_key)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": "hello"}
            ]
        )
        print("OpenAI Success")
    except Exception as e:
        print("OpenAI Error:", e)

if HAS_GEMINI:
    try:
        api_key = os.getenv("GEMINI_API_KEY")
        client = genai.Client(api_key=api_key)
        r = client.models.generate_content(model='gemini-flash-latest', contents=["hello"])
        print("Gemini Success")
    except Exception as e:
        print("Gemini Error:", e)
