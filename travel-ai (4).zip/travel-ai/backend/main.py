import os
import sqlite3
import uuid
from typing import Optional
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Response, Cookie
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

try:
    from google import genai
    HAS_GEMINI = True
except ImportError:
    HAS_GEMINI = False

try:
    from openai import OpenAI as OpenAIClient
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

load_dotenv()
if os.environ.get("VERCEL"):
    DB_FILE = "/tmp/travel.db"
else:
    DB_FILE = "travel.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT UNIQUE,
        password TEXT, is_admin BOOLEAN DEFAULT 0, session_token TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS destinations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT,
        location TEXT, price INTEGER, days INTEGER, type TEXT,
        image_url TEXT, extra_images TEXT, includes TEXT,
        likes INTEGER DEFAULT 0, bookings INTEGER DEFAULT 0,
        lat REAL, lon REAL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, destination_id INTEGER,
        user_id INTEGER, text TEXT, rating INTEGER DEFAULT 5,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS saved_cities (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        destination_id INTEGER, UNIQUE(user_id, destination_id)
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        message TEXT, reply TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        destination_id INTEGER, guests INTEGER DEFAULT 1,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )""")

    # 10 ta real joy
    c.execute("SELECT COUNT(*) FROM destinations")
    if c.fetchone()[0] == 0:
        data = [
            ("Registon Maydoni",
             "Samarqandning yuragi — Ulug'bek, Sherdor va Tillakori madrasalari ansambli. UNESCO merosi.",
             "Samarqand, O'zbekiston", 150, 2, "culture",
             "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Registan_-_Samarkand_-_15-10-2011.jpg/800px-Registan_-_Samarkand_-_15-10-2011.jpg",
             "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Samarkand_Registan_2006.jpg/640px-Samarkand_Registan_2006.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Registan_square_Samarkand.jpg/640px-Registan_square_Samarkand.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Ulugh_Beg_Madrasah.jpg/640px-Ulugh_Beg_Madrasah.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Sherdor_madrasa_Samarkand.jpg/640px-Sherdor_madrasa_Samarkand.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Tillya-Kori_Madrasah.jpg/640px-Tillya-Kori_Madrasah.jpg",
             "Mehmonxona, Gid, Kirish chiptalari, Transport, Nonushta", 1200, 450, 39.6548, 66.9757),

            ("Ark Qal'asi",
             "Buxoro amirlarining 2000 yillik qadimiy qarorgohi. Ichida muzeylar va tarixiy xonalar.",
             "Buxoro, O'zbekiston", 120, 2, "culture",
             "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Bukhara_Fortress_%28Ark%29.jpg/800px-Bukhara_Fortress_%28Ark%29.jpg",
             "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Po-i-Kalyan.jpg/640px-Po-i-Kalyan.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Poi_Kalon_Mosque.jpg/640px-Poi_Kalon_Mosque.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Kalon_Minaret.jpg/640px-Kalon_Minaret.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Samanid_Mausoleum.jpg/640px-Samanid_Mausoleum.jpg,https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Lyab-i_Hauz.jpg/640px-Lyab-i_Hauz.jpg",
             "Mehmonxona, Ekskursiya, Buxoro palovi, Milliy shou", 950, 300, 39.7745, 64.4154),

            ("Chimyon Tog'lari",
             "Toshkent yaqinidagi mashhur tog' kurorti. Qishda chang'i, yozda trekking. Toza havo.",
             "Toshkent viloyati", 200, 3, "mountain",
             "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80",
             "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?w=600&q=80,https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=600&q=80,https://images.unsplash.com/photo-1483728642387-6c3bdd6c93e5?w=600&q=80,https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80,https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600&q=80",
             "Kottej, Chang'i ijarasi, Nonushta, Transport, Gid", 800, 200, 41.55, 70.00),

            ("Charvak Ko'li",
             "Tog'lar orasidagi moviy ko'l. Plyaj, qayiq sayr, paraplan. Yozgi dam olish uchun ideal.",
             "Toshkent viloyati", 180, 2, "beach",
             "https://images.unsplash.com/photo-1439066615861-d1af74d74000?w=800&q=80",
             "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&q=80,https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&q=80,https://images.unsplash.com/photo-1433838552652-f9a46b332c40?w=600&q=80,https://images.unsplash.com/photo-1506929562872-bb421503ef21?w=600&q=80,https://images.unsplash.com/photo-1468413253725-0d5181091126?w=600&q=80",
             "Mehmonxona, Qayiq sayr, Nonushta, Plyaj, Paraplan", 600, 350, 41.62, 69.98),

            ("Santorini Oroli",
             "Gretsiyaning eng romantik oroli. Oq uylar, ko'k gumbazlar, ajoyib quyosh botishi.",
             "Gretsiya", 2000, 5, "beach",
             "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&q=80",
             "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=600&q=80,https://images.unsplash.com/photo-1533105079780-92b9be482077?w=600&q=80,https://images.unsplash.com/photo-1504512485720-7d83a16ee930?w=600&q=80,https://images.unsplash.com/photo-1580502304784-8985b7eb7260?w=600&q=80,https://images.unsplash.com/photo-1601581875039-e899893d520c?w=600&q=80",
             "5* Mehmonxona, Yaxtada sayr, Nonushta, Gid, Vineyardlar", 1800, 400, 36.39, 25.46),

            ("Maldiv Orollari",
             "Hind okeanidagi jannat. Oq qum, tiniq suv, suv ustidagi villalar.",
             "Maldiv", 3500, 7, "beach",
             "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800&q=80",
             "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?w=600&q=80,https://images.unsplash.com/photo-1540202404-a2f29016b523?w=600&q=80,https://images.unsplash.com/photo-1512100356956-c12878394045?w=600&q=80,https://images.unsplash.com/photo-1544550581-5f7ceaf7f992?w=600&q=80,https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=600&q=80",
             "Suv usti Villa, Parvoz, 3 mahal ovqat, Spa, Snorkeling", 3000, 800, 3.20, 73.22),

            ("Dubay Shahri",
             "Zamonaviy mo'jiza. Burj Xalifa, Palm Jumeirah, cho'l safari.",
             "BAA", 1500, 5, "city",
             "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&q=80",
             "https://images.unsplash.com/photo-1518684079-3c830dffe094?w=600&q=80,https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?w=600&q=80,https://images.unsplash.com/photo-1582672060674-bc2bd808a8b5?w=600&q=80,https://images.unsplash.com/photo-1580674684081-7617fbf3d745?w=600&q=80,https://images.unsplash.com/photo-1546412414-e1885259563a?w=600&q=80",
             "5* Mehmonxona, Parvoz, Cho'l safari, Burj Xalifa, Mall", 2200, 600, 25.20, 55.27),

            ("Parij — Eyfel Minorasi",
             "Ishq shahri. Eyfel minorasi, Luvr, Yeliseylar dalalari, Monmartr.",
             "Fransiya", 1800, 4, "city",
             "https://images.unsplash.com/photo-1502602898657-3e907fa00868?w=800&q=80",
             "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&q=80,https://images.unsplash.com/photo-1431274172761-fca41d930114?w=600&q=80,https://images.unsplash.com/photo-1550340499-a6c60fc8287c?w=600&q=80,https://images.unsplash.com/photo-1549144511-f099e773c147?w=600&q=80,https://images.unsplash.com/photo-1471623320832-752e8bbf8413?w=600&q=80",
             "Mehmonxona, Parvoz, Luvr chiptasi, Eyfel, Gid", 2500, 550, 48.86, 2.35),

            ("Bali Oroli",
             "Indoneziyaning go'zal oroli. Ibodatxonalar, guruch terrasalari, serfing.",
             "Indoneziya", 1200, 6, "beach",
             "https://images.unsplash.com/photo-1537996194471-e657a9e3e9d0?w=800&q=80",
             "https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=600&q=80,https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=600&q=80,https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?w=600&q=80,https://images.unsplash.com/photo-1573790387438-4da905039392?w=600&q=80,https://images.unsplash.com/photo-1536152470836-b943b246130c?w=600&q=80",
             "Villa, Parvoz, Spa, Serfing darsi, Ekskursiya", 1500, 700, -8.34, 115.09),

            ("Kappadokiya",
             "Turkiyadagi tabiiy mo'jiza. Havo sharlari, yer osti shaharlari, g'aroyib qoyalar.",
             "Turkiya", 800, 3, "culture",
             "https://images.unsplash.com/photo-1641128324972-af3212f0f6bd?w=800&q=80",
             "https://images.unsplash.com/photo-1570939274717-7eda259b50ed?w=600&q=80,https://images.unsplash.com/photo-1526048598645-62b31f82b8f5?w=600&q=80,https://images.unsplash.com/photo-1562932831-afcfe48b5786?w=600&q=80,https://images.unsplash.com/photo-1609866138210-84bb689f3c61?w=600&q=80,https://images.unsplash.com/photo-1605833556294-ea5c7a74f57d?w=600&q=80",
             "Mehmonxona, Havo shari, Yer osti shahri, Nonushta, Gid", 1100, 900, 38.64, 34.83),
        ]
        c.executemany("""INSERT INTO destinations
            (title,description,location,price,days,type,image_url,extra_images,includes,likes,bookings,lat,lon)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", data)

    c.execute("SELECT COUNT(*) FROM users WHERE phone='admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (name,phone,password,is_admin) VALUES ('Admin','admin','admin123',1)")

    conn.commit()
    conn.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def get_user(session_token: Optional[str] = Cookie(None)):
    if not session_token: return None
    conn = get_db()
    u = conn.execute("SELECT id,name,phone,is_admin FROM users WHERE session_token=?", (session_token,)).fetchone()
    conn.close()
    return dict(u) if u else None

# ===== AUTH =====
class Reg(BaseModel):
    name: str; phone: str; password: str
class Log(BaseModel):
    phone: str; password: str

@app.post("/api/auth/register")
def register(req: Reg, response: Response):
    conn = get_db()
    try:
        tok = str(uuid.uuid4())
        conn.execute("INSERT INTO users (name,phone,password,session_token) VALUES (?,?,?,?)", (req.name,req.phone,req.password,tok))
        conn.commit(); conn.close()
        response.set_cookie("session_token", tok, httponly=True)
        return {"success": True, "name": req.name}
    except sqlite3.IntegrityError:
        conn.close()
        raise HTTPException(400, "Bu raqam allaqachon ro'yxatdan o'tgan")

@app.post("/api/auth/login")
def login(req: Log, response: Response):
    conn = get_db()
    u = conn.execute("SELECT * FROM users WHERE phone=?", (req.phone,)).fetchone()
    if u and u["password"] == req.password:
        tok = str(uuid.uuid4())
        conn.execute("UPDATE users SET session_token=? WHERE id=?", (tok, u["id"]))
        conn.commit(); conn.close()
        response.set_cookie("session_token", tok, httponly=True)
        return {"success": True, "name": u["name"], "is_admin": bool(u["is_admin"])}
    conn.close()
    raise HTTPException(401, "Noto'g'ri raqam yoki parol")

@app.post("/api/auth/logout")
def logout(response: Response):
    response.delete_cookie("session_token")
    return {"success": True}

@app.get("/api/auth/me")
def me(session_token: Optional[str] = Cookie(None)):
    u = get_user(session_token)
    return {"logged_in": True, "user": u} if u else {"logged_in": False}

# ===== DESTINATIONS =====
@app.get("/api/destinations")
def list_dests(q: Optional[str]=None, type: Optional[str]=None, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    conn = get_db()
    sql = "SELECT d.*, (SELECT AVG(rating) FROM comments WHERE destination_id=d.id) as avg_rating FROM destinations d WHERE 1=1"
    p = []
    if q: sql += " AND (title LIKE ? OR location LIKE ?)"; p += [f"%{q}%", f"%{q}%"]
    if type: sql += " AND type=?"; p.append(type)
    rows = [dict(r) for r in conn.execute(sql, p).fetchall()]
    saved = []
    if u: saved = [r[0] for r in conn.execute("SELECT destination_id FROM saved_cities WHERE user_id=?", (u["id"],)).fetchall()]
    conn.close()
    for r in rows:
        r["is_saved"] = r["id"] in saved
        r["avg_rating"] = round(r["avg_rating"] or 5.0, 1)
    return rows

@app.get("/api/destinations/{did}")
def get_dest(did: int, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    conn = get_db()
    r = conn.execute("SELECT d.*, (SELECT AVG(rating) FROM comments WHERE destination_id=d.id) as avg_rating FROM destinations d WHERE id=?", (did,)).fetchone()
    if not r: conn.close(); raise HTTPException(404)
    d = dict(r)
    d["avg_rating"] = round(d["avg_rating"] or 5.0, 1)
    d["comments"] = [dict(c) for c in conn.execute("SELECT c.text,c.rating,c.timestamp,u.name FROM comments c JOIN users u ON c.user_id=u.id WHERE c.destination_id=? ORDER BY c.id DESC", (did,)).fetchall()]
    d["is_saved"] = False
    if u: d["is_saved"] = bool(conn.execute("SELECT 1 FROM saved_cities WHERE user_id=? AND destination_id=?", (u["id"],did)).fetchone())
    conn.close()
    return d

class Act(BaseModel):
    dest_id: int

@app.post("/api/destinations/like")
def like(req: Act):
    conn = get_db(); conn.execute("UPDATE destinations SET likes=likes+1 WHERE id=?", (req.dest_id,)); conn.commit(); conn.close()
    return {"success": True}

@app.post("/api/destinations/save")
def save(req: Act, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u: raise HTTPException(401)
    conn = get_db()
    try:
        conn.execute("INSERT INTO saved_cities (user_id,destination_id) VALUES (?,?)", (u["id"],req.dest_id)); conn.commit(); s="saved"
    except sqlite3.IntegrityError:
        conn.execute("DELETE FROM saved_cities WHERE user_id=? AND destination_id=?", (u["id"],req.dest_id)); conn.commit(); s="unsaved"
    conn.close()
    return {"success": True, "status": s}

@app.post("/api/destinations/book")
def book(req: Act, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u: raise HTTPException(401, "Tizimga kiring")
    conn = get_db()
    conn.execute("UPDATE destinations SET bookings=bookings+1 WHERE id=?", (req.dest_id,))
    conn.execute("INSERT INTO bookings (user_id,destination_id) VALUES (?,?)", (u["id"],req.dest_id))
    conn.commit(); conn.close()
    return {"success": True}

# ===== COMMENTS =====
class ComReq(BaseModel):
    dest_id: int; text: str; rating: int = 5

@app.post("/api/destinations/comment")
def comment(req: ComReq, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u: raise HTTPException(401)
    conn = get_db()
    conn.execute("INSERT INTO comments (destination_id,user_id,text,rating) VALUES (?,?,?,?)", (req.dest_id,u["id"],req.text,req.rating))
    conn.commit(); conn.close()
    return {"success": True}

# ===== ADMIN =====
@app.get("/api/admin/stats")
def admin_stats(session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u or not u.get("is_admin"): raise HTTPException(403)
    conn = get_db()
    users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    bks = conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
    rev = conn.execute("SELECT COALESCE(SUM(d.price),0) FROM bookings b JOIN destinations d ON b.destination_id=d.id").fetchone()[0]
    top = [dict(r) for r in conn.execute("SELECT title,bookings,likes FROM destinations ORDER BY bookings DESC LIMIT 5").fetchall()]
    conn.close()
    return {"total_users": users, "total_bookings": bks, "total_revenue": rev, "top": top}

@app.get("/api/admin/bookings")
def admin_bookings(session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u or not u.get("is_admin"): raise HTTPException(403)
    conn = get_db()
    rows = [dict(r) for r in conn.execute("""
        SELECT b.id, u.name as user_name, u.phone, d.title as city, d.price, b.timestamp
        FROM bookings b JOIN users u ON b.user_id=u.id JOIN destinations d ON b.destination_id=d.id
        ORDER BY b.timestamp DESC
    """).fetchall()]
    conn.close()
    return rows

@app.get("/api/admin/users")
def admin_users(session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    if not u or not u.get("is_admin"): raise HTTPException(403)
    conn = get_db()
    rows = [dict(r) for r in conn.execute("SELECT id,name,phone,is_admin,created_at FROM users ORDER BY id").fetchall()]
    conn.close()
    return rows

# ===== AI MODELS =====
class ChatReq(BaseModel):
    message: str
class ImgReq(BaseModel):
    prompt: str

# ===== AI HELPERS =====
def get_tours_context():
    conn = get_db()
    tours = conn.execute("SELECT title,location,price,days,type FROM destinations").fetchall()
    conn.close()
    return "\n".join([f"- {t['title']} ({t['location']}), ${t['price']}, {t['days']} kun" for t in tours])

def try_chatgpt(system_prompt: str, user_msg: str) -> str:
    """ChatGPT bilan javob olishga harakat qiladi."""
    if not HAS_OPENAI:
        raise Exception("OpenAI kutubxonasi yo'q")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise Exception("OPENAI_API_KEY yo'q")
    client = OpenAIClient(api_key=api_key)
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_msg}
        ],
        max_tokens=800,
        temperature=0.7
    )
    return resp.choices[0].message.content.strip()

def try_gemini(prompt: str, user_msg: str) -> str:
    """Gemini bilan javob olishga harakat qiladi."""
    if not HAS_GEMINI:
        raise Exception("Gemini kutubxonasi yo'q")
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise Exception("GEMINI_API_KEY yo'q")
    client = genai.Client(api_key=api_key)
    r = client.models.generate_content(model='gemini-flash-latest', contents=[prompt, user_msg])
    return r.text.strip()

@app.post("/api/ai/chat")
def ai_chat(req: ChatReq, session_token: Optional[str]=Cookie(None)):
    u = get_user(session_token)
    ctx = get_tours_context()
    system_prompt = f"""Siz tajribali AI Sayohat Maslahatchisisiz. O'zbek tilida javob bering. 
Bizning turlarimiz:\n{ctx}\nMijozga eng mos turni tavsiya qiling. Qisqa va chiroyli javob bering."""
    
    reply = None
    used_model = None
    
    # 1. Gemini ni sinab ko'ramiz
    try:
        reply = try_gemini(system_prompt, req.message)
        used_model = "Gemini Flash"
    except Exception as e1:
        print(f"Gemini xato: {e1}")
        # 2. ChatGPT ga o'tamiz (fallback)
        try:
            reply = try_chatgpt(system_prompt, req.message)
            used_model = "ChatGPT (gpt-4o-mini)"
        except Exception as e2:
            print(f"ChatGPT xato: {e2}")
            reply = "Kechirasiz, hozirda AI xizmati ishlamayapti. Iltimos keyinroq urinib ko'ring."
            used_model = None
    
    if u and reply:
        conn2 = get_db()
        conn2.execute("INSERT INTO chat_history (user_id,message,reply) VALUES (?,?,?)", (u["id"],req.message,reply))
        conn2.commit(); conn2.close()
    
    return {"reply": reply, "model": used_model}


@app.post("/api/ai/imagine")
def ai_imagine(req: ImgReq):
    if not HAS_GEMINI: return {"title":"Xato","description":"Gemini ulanmagan","price":0,"image_url":"","lat":0,"lon":0}
    api_key = os.getenv("GEMINI_API_KEY")
    try:
        client = genai.Client(api_key=api_key)
        r = client.models.generate_content(model='gemini-flash-latest', contents=[
            "Foydalanuvchi aytgan joyga oid qisqa tavsif, taxminiy narx va koordinatalarni JSON formatda ber: {title, description, price, location, lat, lon}. Faqat JSON qaytar.",
            req.prompt
        ])
        import json, re
        m = re.search(r'\{.*\}', r.text, re.DOTALL)
        if m: d = json.loads(m.group())
        else: raise ValueError()
        d["image_url"] = f"https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800&q=80"
        return d
    except:
        return {"title":"Orzuingizdagi joy","description":"AI hozircha tasvirlay olmadi.","price":1000,"location":"Noma'lum","image_url":"https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800","lat":0,"lon":0}

# Frontend mount
fp = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(fp):
    app.mount("/", StaticFiles(directory=fp, html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
