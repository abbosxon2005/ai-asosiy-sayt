@echo off
echo ==============================================
echo       AI Travel Planner - Ishga Tushirish
echo ==============================================

:: Python o'rnatilganini tekshirish
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo XATO: Python kompyuteringizga o'rnatilmagan yoki PATH ga qo'shilmagan!
    echo Iltimos, python.org saytidan Pythonni yuklab oling va o'rnating.
    pause
    exit /b
)

echo AI Travel Planner tayyorlanmoqda...
echo Brauzer avtomatik ochiladi. Iltimos qora oynani yopmang!
echo.

cd backend

:: Check if venv exists, if not create it and install requirements
if not exist "venv\" (
    echo Virtual muhit yaratilmoqda...
    python -m venv venv
    call venv\Scripts\activate.bat
    echo Kutubxonalar ornatilmoqda fastapi, uvicorn, pydantic, google-genai...
    pip install fastapi uvicorn pydantic python-dotenv google-genai httpx
) else (
    call venv\Scripts\activate.bat
)

start http://localhost:8000
python main.py

pause
