let allTours = [];
let currentUser = null;
let map = null;
let markers = [];
let currentCurrency = 'USD';
const UZS_RATE = 12800;
let fetchTimeout = null;

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    fetchTours();
    setTimeout(initMap, 600);
    gsap.from('.hero-content > *', { y: 40, opacity: 0, duration: 0.8, stagger: 0.15, ease: 'power3.out' });
});

// ====== AUTH ======
async function checkAuth() {
    try {
        const res = await fetch('/api/auth/me');
        const data = await res.json();
        if (data.logged_in) {
            currentUser = data.user;
            document.getElementById('authSection').style.display = 'none';
            document.getElementById('userSection').style.display = 'flex';
            document.getElementById('userNameDisplay').textContent = currentUser.name;
            document.getElementById('userAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
            if (currentUser.is_admin) document.getElementById('adminBtn').style.display = 'inline-flex';
        } else {
            currentUser = null;
            document.getElementById('authSection').style.display = 'flex';
            document.getElementById('userSection').style.display = 'none';
        }
    } catch (e) {}
}

function openAuthModal(tab) {
    document.getElementById('authModal').style.display = 'block';
    switchAuthTab(tab || 'login');
}
function switchAuthTab(tab) {
    document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
    document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
    document.getElementById('loginForm').classList.toggle('active-form', tab === 'login');
    document.getElementById('registerForm').classList.toggle('active-form', tab === 'register');
}

async function login() {
    const phone = document.getElementById('loginPhone').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    if (!phone || !password) return alert("Barcha maydonlarni to'ldiring!");
    const res = await fetch('/api/auth/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({phone,password}) });
    if (res.ok) { closeModal('authModal'); checkAuth(); fetchTours(); }
    else { const d = await res.json(); alert(d.detail || "Xato!"); }
}

async function register() {
    const name = document.getElementById('regName').value.trim();
    const phone = document.getElementById('regPhone').value.trim();
    const password = document.getElementById('regPassword').value.trim();
    if (!name || !phone || !password) return alert("Barcha maydonlarni to'ldiring!");
    const res = await fetch('/api/auth/register', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({name,phone,password}) });
    if (res.ok) { closeModal('authModal'); checkAuth(); fetchTours(); }
    else { const d = await res.json(); alert(d.detail || "Xato!"); }
}

async function logout() { await fetch('/api/auth/logout', {method:'POST'}); location.reload(); }

// ====== TOURS ======
async function fetchTours(query = '', type = '') {
    try {
        let url = '/api/destinations?_=1';
        if (query) url += '&q=' + encodeURIComponent(query);
        if (type) url += '&type=' + type;
        const res = await fetch(url);
        allTours = await res.json();
        renderTours(allTours);
        if (map) updateMapMarkers(allTours);
    } catch (e) {
        document.getElementById('toursGrid').innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem">Turlarni yuklab bo\'lmadi.</p>';
    }
}

function renderTours(tours) {
    const grid = document.getElementById('toursGrid');
    grid.innerHTML = '';
    if (!tours.length) { grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem">Hech narsa topilmadi</p>'; return; }
    tours.forEach((tour, i) => {
        const price = formatPrice(tour.price);
        const card = document.createElement('div');
        card.className = 'tour-card';
        card.onclick = () => openTourDetails(tour.id);
        card.innerHTML = `
            <div class="tour-img-wrap">
                <img src="${tour.image_url}" alt="${tour.title}" width="400" height="240" onerror="this.src='https://picsum.photos/400/240?random=${tour.id}'">
                <div class="tour-badge">${tour.type}</div>
                <div class="tour-rating-badge"><i class="ri-star-fill"></i> ${tour.avg_rating}</div>
            </div>
            <div class="tour-info">
                <h3>${tour.title}</h3>
                <div class="tour-location"><i class="ri-map-pin-2-fill"></i> ${tour.location}</div>
                <div class="tour-footer">
                    <div class="tour-price">${price} <span class="currency-label">/ kishi</span></div>
                    <div class="tour-days"><i class="ri-calendar-line"></i> ${tour.days} kun</div>
                </div>
            </div>`;

        grid.appendChild(card);
        gsap.from(card, { 
            opacity: 0, y: 30, duration: 0.5, delay: i * 0.07, 
            ease: 'power2.out', clearProps: 'opacity,transform'
        });
    });
}

function formatPrice(usd) {
    return currentCurrency === 'UZS' ? (usd * UZS_RATE).toLocaleString() + " so'm" : '$' + usd;
}
function changeCurrency() { currentCurrency = document.getElementById('currencySelect').value; renderTours(allTours); }

// ====== FILTERS ======
function debounceFetch() { clearTimeout(fetchTimeout); fetchTimeout = setTimeout(() => fetchTours(document.getElementById('searchInput').value), 400); }
function filterByType(el, type) {
    document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    fetchTours(document.getElementById('searchInput').value, type);
}

// ====== MAP ======
function initMap() {
    try {
        map = L.map('map').setView([38, 55], 4);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(map);
        updateMapMarkers(allTours);
    } catch (e) {}
}
function updateMapMarkers(tours) {
    if (!map) return;
    markers.forEach(m => map.removeLayer(m)); markers = [];
    tours.forEach(t => {
        if (t.lat && t.lon) {
            const m = L.marker([t.lat, t.lon]).addTo(map);
            m.bindPopup(`<div style="text-align:center;min-width:120px"><b>${t.title}</b><br><span style="color:#6366f1;font-weight:800">$${t.price}</span><br><small>${t.location}</small></div>`);
            markers.push(m);
        }
    });
}

// ====== AI CHAT ======
async function sendMessage() {
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    appendMsg(msg, 'user-msg');
    const typingId = 'typing-' + Date.now();
    appendMsg('<i class="ri-loader-4-line" style="animation:spin 0.8s linear infinite;display:inline-block"></i> O\'ylanmoqda...', 'bot-msg', typingId);
    try {
        const res = await fetch('/api/ai/chat', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({message:msg}) });
        const data = await res.json();
        const t = document.getElementById(typingId); if (t) t.remove();
        const modelLabel = data.model ? `<div style="font-size:0.75rem;color:var(--primary-light);margin-bottom:4px;opacity:0.8">🤖 ${data.model}</div>` : '';
        appendMsg(modelLabel + data.reply, 'bot-msg');
    } catch (e) {
        const t = document.getElementById(typingId); if (t) t.remove();
        appendMsg("Xatolik yuz berdi.", 'bot-msg');
    }
}
function appendMsg(text, cls, id = '') {
    const box = document.getElementById('chatBox');
    const div = document.createElement('div');
    div.className = 'msg-bubble ' + cls;
    if (id) div.id = id;
    div.innerHTML = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

// ====== DREAM AI ======
function openDreamAI() { document.getElementById('dreamModal').style.display = 'block'; }
async function generateDream() {
    const prompt = document.getElementById('dreamPrompt').value.trim();
    if (!prompt) return alert("Joyni tasvirlab bering!");
    const btn = document.getElementById('btnImagine');
    btn.innerHTML = '<i class="ri-loader-4-line" style="animation:spin 0.8s linear infinite;display:inline-block"></i> Yaratilmoqda...';
    btn.disabled = true;
    try {
        const res = await fetch('/api/ai/imagine', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({prompt}) });
        const d = await res.json();
        document.getElementById('dreamResult').innerHTML = `
            <div class="dream-result-card">
                <img src="${d.image_url}" onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'">
                <div class="dream-result-info"><h4>${d.title}</h4><p>${d.description}</p><div class="dream-price">$${d.price}</div></div>
            </div>`;
    } catch (e) { document.getElementById('dreamResult').innerHTML = '<p style="color:#ef4444">AI bilan aloqa uzildi.</p>'; }
    finally { btn.innerHTML = '<i class="ri-magic-line"></i> Yaratish'; btn.disabled = false; }
}

// ====== TOUR DETAIL ======
function openTourDetails(id) {
    document.getElementById('tourModal').style.display = 'block';
    const body = document.getElementById('tourDetailBody');
    body.innerHTML = '<div class="loader"></div>';
    fetch('/api/destinations/' + id).then(r => r.json()).then(tour => {
        const price = formatPrice(tour.price);

        // Extra images
        let extraHtml = '';
        let allImgUrls = [tour.image_url];
        if (tour.extra_images) {
            const urls = tour.extra_images.split(',').filter(u => u.trim());
            allImgUrls = [tour.image_url, ...urls];
            if (urls.length) {
                const urlsJson = JSON.stringify(allImgUrls);
                extraHtml = '<div class="extra-images">' + 
                    allImgUrls.map((u, i) => 
                        `<img src="${u.trim()}" onclick='openLightbox(${urlsJson}, ${i})' title="Kattalashtirish">`
                    ).join('') + 
                '</div>';
            }
        }

        // Includes
        let includesHtml = '';
        if (tour.includes) {
            includesHtml = '<div class="includes-grid">' + tour.includes.split(',').map(i => `<span><i class="ri-check-line"></i> ${i.trim()}</span>`).join('') + '</div>';
        }

        // Comments
        const commentsHtml = tour.comments.map(c => `
            <div class="comment-card">
                <div class="comment-header"><strong>${c.name}</strong><span class="comment-stars">${'★'.repeat(c.rating)}${'☆'.repeat(5-c.rating)}</span></div>
                <div class="comment-text">${c.text}</div>
                <div class="comment-time">${new Date(c.timestamp).toLocaleString()}</div>
            </div>`).join('') || '<p style="color:var(--text-muted)">Hali izohlar yo\'q.</p>';

        body.innerHTML = `
            <img src="${tour.image_url}" style="width:100%;height:350px;object-fit:cover" onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'">
            <div style="padding:2rem">
                <h2 style="font-size:2rem;margin-bottom:0.3rem">${tour.title}</h2>
                <p style="color:var(--primary-light);margin-bottom:1.5rem"><i class="ri-map-pin-2-fill"></i> ${tour.location} · <i class="ri-calendar-line"></i> ${tour.days} kun · <i class="ri-star-fill"></i> ${tour.avg_rating}</p>

                <div class="ai-insight-box" style="background:rgba(99,102,241,0.08);border:1px dashed var(--primary);padding:1rem 1.2rem;border-radius:14px;margin-bottom:1.5rem;color:var(--primary-light);display:flex;gap:10px">
                    <i class="ri-robot-2-fill" style="font-size:1.3rem;flex-shrink:0"></i>
                    <div><strong>AI Tavsiya:</strong> Bu yo'nalish so'nggi oyda ${tour.bookings} marta bron qilingan. Narxlar kelajak haftalarda o'sishi kutilmoqda!</div>
                </div>

                <p style="color:var(--text-muted);line-height:1.8;margin-bottom:1rem">${tour.description}</p>
                ${extraHtml}
                ${includesHtml}

                <div style="display:flex;justify-content:space-between;align-items:center;background:rgba(255,255,255,0.03);border:1px solid var(--border);padding:1.5rem 2rem;border-radius:18px;margin:1.5rem 0">
                    <div>
                        <p style="color:var(--text-muted);font-size:0.85rem">Boshlang'ich narx</p>
                        <h2 style="color:var(--primary-light);font-size:2rem">${price}</h2>
                        <p style="color:var(--text-muted);font-size:0.8rem"><i class="ri-group-fill"></i> ${tour.bookings} marta bron qilingan</p>
                    </div>
                    <button class="btn-primary" onclick="bookTour(${tour.id})"><i class="ri-bookmark-3-fill"></i> Bron Qilish</button>
                </div>

                <div class="comments-section">
                    <h3 style="margin-bottom:1rem">Izohlar</h3>
                    <div class="comment-form">
                        <input type="text" id="commentInput_${tour.id}" placeholder="Fikr yozish...">
                        <button class="btn-primary-sm" onclick="submitComment(${tour.id})">Yuborish</button>
                    </div>
                    ${commentsHtml}
                </div>
            </div>`;
    }).catch(() => { body.innerHTML = '<p style="text-align:center;padding:3rem;color:var(--text-muted)">Xatolik</p>'; });
}

async function bookTour(id) {
    if (!currentUser) { closeModal('tourModal'); openAuthModal('login'); return; }
    if (!confirm("Ushbu sayohatni bron qilasizmi?")) return;
    await fetch('/api/destinations/book', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({dest_id:id}) });
    alert("✅ Muvaffaqiyatli bron qilindi!");
    closeModal('tourModal'); fetchTours();
}

async function submitComment(id) {
    if (!currentUser) { openAuthModal('login'); return; }
    const input = document.getElementById('commentInput_' + id);
    const text = input.value.trim();
    if (!text) return;
    await fetch('/api/destinations/comment', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({dest_id:id, text, rating:5}) });
    openTourDetails(id);
}

// ====== ADMIN ======
async function openAdminPanel() {
    document.getElementById('adminModal').style.display = 'block';
    // Stats
    const statsRes = await fetch('/api/admin/stats');
    const stats = await statsRes.json();
    document.getElementById('adminStats').innerHTML = `
        <div class="admin-stat-card"><h3>${stats.total_users}</h3><p>Foydalanuvchilar</p></div>
        <div class="admin-stat-card"><h3>${stats.total_bookings}</h3><p>Jami Bronlar</p></div>
        <div class="admin-stat-card"><h3>$${stats.total_revenue.toLocaleString()}</h3><p>Jami Daromad</p></div>
    `;
    loadAdminBookings();
}

function switchAdminTab(el, tab) {
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    if (tab === 'bookings') loadAdminBookings();
    else loadAdminUsers();
}

async function loadAdminBookings() {
    const content = document.getElementById('adminContent');
    content.innerHTML = '<div class="loader"></div>';
    const res = await fetch('/api/admin/bookings');
    const bookings = await res.json();
    if (!bookings.length) { content.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:2rem">Hali bronlar yo\'q</p>'; return; }
    content.innerHTML = `<div style="overflow-x:auto"><table class="admin-table">
        <thead><tr><th>Ism</th><th>Telefon</th><th>Sayohat</th><th>Narx</th><th>Sana</th></tr></thead>
        <tbody>${bookings.map(b => `<tr><td>${b.user_name}</td><td>${b.phone}</td><td>${b.city}</td><td>$${b.price}</td><td>${new Date(b.timestamp).toLocaleString()}</td></tr>`).join('')}</tbody>
    </table></div>`;
}

async function loadAdminUsers() {
    const content = document.getElementById('adminContent');
    content.innerHTML = '<div class="loader"></div>';
    const res = await fetch('/api/admin/users');
    const users = await res.json();
    content.innerHTML = `<div style="overflow-x:auto"><table class="admin-table">
        <thead><tr><th>ID</th><th>Ism</th><th>Telefon</th><th>Rol</th><th>Sana</th></tr></thead>
        <tbody>${users.map(u => `<tr><td>${u.id}</td><td>${u.name}</td><td>${u.phone}</td><td>${u.is_admin ? '<span class="badge-admin">Admin</span>' : '<span class="badge-user">User</span>'}</td><td>${u.created_at ? new Date(u.created_at).toLocaleString() : '-'}</td></tr>`).join('')}</tbody>
    </table></div>`;
}

// ====== LIGHTBOX ======
let lbImages = [];
let lbIndex = 0;

function openLightbox(imgs, index) {
    lbImages = imgs;
    lbIndex = index;
    const lb = document.getElementById('lightbox');
    const img = document.getElementById('lightboxImg');
    img.src = lbImages[lbIndex];
    document.getElementById('lbCounter').textContent = `${lbIndex + 1} / ${lbImages.length}`;
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    document.getElementById('lightbox').classList.remove('open');
    document.body.style.overflow = '';
}

function lbMove(dir) {
    lbIndex = (lbIndex + dir + lbImages.length) % lbImages.length;
    const img = document.getElementById('lightboxImg');
    img.style.animation = 'none';
    img.offsetHeight; // reflow
    img.style.animation = '';
    img.src = lbImages[lbIndex];
    document.getElementById('lbCounter').textContent = `${lbIndex + 1} / ${lbImages.length}`;
}

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (!document.getElementById('lightbox').classList.contains('open')) return;
    if (e.key === 'ArrowRight') lbMove(1);
    if (e.key === 'ArrowLeft') lbMove(-1);
    if (e.key === 'Escape') closeLightbox();
});

// ====== UTILS ======
function closeModal(id) { document.getElementById(id).style.display = 'none'; }
window.onclick = (e) => { if (e.target.classList.contains('modal')) e.target.style.display = 'none'; };
